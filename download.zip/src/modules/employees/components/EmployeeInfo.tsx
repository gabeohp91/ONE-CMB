tsx
const EmployeeInfo = () => {
  return (
    <div>
      <p>Loading employee information...</p>
    </div>
  );
};

export default EmployeeInfo;