tsx
const AIPrompt = () => {
  return <div>Loading...</div>;
};

export default AIPrompt;