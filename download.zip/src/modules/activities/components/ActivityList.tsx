tsx
const ActivityList = () => {
  return <div>Loading activities...</div>;
};

export default ActivityList;