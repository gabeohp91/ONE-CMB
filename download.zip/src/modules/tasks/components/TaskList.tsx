tsx
const TaskList = () => {
  return <div>Loading tasks...</div>;
};

export default TaskList;