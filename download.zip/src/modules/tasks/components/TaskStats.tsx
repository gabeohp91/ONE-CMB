tsx
const TaskStats = () => {
  return <div>Loading Task Stats...</div>;
};

export default TaskStats;