export const notificationData = [
    { id: 1, title: 'Thông báo 1', date: '14/03/2025', status: 'Đã duyệt', statusColor: 'bg-green-500' },
    { id: 2, title: 'Thông báo 2', date: '10/03/2025', status: 'Đã duyệt', statusColor: 'bg-green-500' },
    { id: 3, title: 'Thông báo 3', date: '08/03/2025', status: 'Đang xử lý', statusColor: 'bg-yellow-500' },
];