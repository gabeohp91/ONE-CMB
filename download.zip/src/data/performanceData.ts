export const performanceData = [
  { name: 'T1', taskCompleted: 12, onTime: 11, total: 13 },
  { name: 'T2', taskCompleted: 15, onTime: 14, total: 16 },
  { name: 'T3', taskCompleted: 14, onTime: 13, total: 15 },
];