export const equipmentData = [
  {
    id: 1,
    name: 'Thiết bị 1',
    type: 'Loại thiết bị 1',
    status: 'Đang sử dụng',
    statusColor: 'bg-green-500',
    assignedDate: '01/06/2023',
  },
  {
    id: 2,
    name: 'Thiết bị 2',
    type: 'Loại thiết bị 2',
    status: 'Đang sử dụng',
    statusColor: 'bg-green-500',
    assignedDate: '15/12/2024',
  },
];