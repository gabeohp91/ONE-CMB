// src/data/resources/types.ts

export interface Resource {
  id: string;
  name: string;
  type: string;
  // Add other relevant properties here
}