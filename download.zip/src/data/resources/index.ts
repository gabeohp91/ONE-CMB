ts
// src/data/resources/index.ts
export * from './resourceTypes';
export * from './equipmentData';