export const taskHistory = [
  {
    id: 101,
    name: 'Công việc đã hoàn thành 1',
    completedDate: '10/03/2025',
    status: 'Hoàn thành',
    statusColor: 'bg-green-500',
    project: 'Dự án D',
    feedback: 'Tốt, đáp ứng yêu cầu',
  },
  {
    id: 102,
    name: 'Công việc đã hoàn thành 2',
    completedDate: '05/03/2025',
    status: 'Hoàn thành',
    statusColor: 'bg-green-500',
    project: 'Dự án E',
    feedback: 'Tốt, phát hiện và sửa nhiều lỗi quan trọng',
  },
];