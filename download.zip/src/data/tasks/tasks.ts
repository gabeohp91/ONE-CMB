// src/data/tasks/tasks.ts
export const tasks = [
  // Add your task data here
];