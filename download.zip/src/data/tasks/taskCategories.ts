// src/data/tasks/taskCategories.ts
export const taskCategories = [
  "Development",
  "Design",
  "Testing",
  "Documentation",
  "Management",
  "Other",
];