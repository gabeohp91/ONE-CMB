// src/data/activities/outgoingActivities.ts
// Define outgoing activities data here

const outgoingActivities = [];

export default outgoingActivities;