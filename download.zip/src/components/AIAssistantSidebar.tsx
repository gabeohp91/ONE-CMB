import React, { useState } from 'react';
import AIAssistant from '@/components/AIAssistant/AIAssistant';
import { Button } from "@/components/ui/button"
import { HelpCircle } from "lucide-react";
import { EmployeeInfo } from '@/types/employeeInfo'; // Assuming you have this type defined

interface AIAssistantSidebarProps {
  employeeInfo: EmployeeInfo;
  activeTab: string;
}
const AIAssistantSidebar: React.FC<AIAssistantSidebarProps> = ({ employeeInfo }) => {
  const [isAIAssistantVisible, setIsAIAssistantVisible] = useState<boolean>(true);
  const toggleAIAssistant = () => {
    setIsAIAssistantVisible(!isAIAssistantVisible);
  };
  const handleCloseAIAssistant = () => {
    setIsAIAssistantVisible(false);
  };
  return (
    <>
      <Button className="fixed right-4 bottom-4 z-50" onClick={toggleAIAssistant}><HelpCircle className="mr-2 h-4 w-4" />AI Assistant</Button>
      {isAIAssistantVisible && (
        <div className="fixed right-0 bottom-0 z-50">
          <AIAssistant employeeInfo={employeeInfo} onClose={handleCloseAIAssistant} />
        </div>
      )}
    </>
  );
};
export default AIAssistantSidebar;