import React from 'react';

const EmployeeDashboard: React.FC = () => {
  return (
    <div>
       Employee Dashboard
    </div>
  );
};

export default EmployeeDashboard;