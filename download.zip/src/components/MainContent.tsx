import React from 'react';

const MainContent: React.FC = () => {
  return (
    <div className="flex-1 p-4 overflow-y-auto pr-96">
      <div className="mt-4">
      </div>
    </div>
  );
};

export default MainContent;