ts
// src/services/api.ts

export const get = async (url: string): Promise<any[]> => {
  return Promise.resolve([]);
};