ts
import { get } from './api';

export const getTasks = async () => {
  // Replace with actual API call when implemented
  // const response = await get('/tasks');
  // return response.data; 
  return [];
};