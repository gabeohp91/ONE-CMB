# Firebase Studio

Project Structure and Descriptions:

.
├── README.md: Project description and documentation.
├── components.json: Configuration for UI components (likely Shadcn UI).
├── next.config.ts: Next.js configuration file.
├── package-lock.json: Records the exact versions of dependencies used.
├── package.json: Project metadata and dependencies.
├── postcss.config.mjs: Configuration for PostCSS (used with Tailwind).
├── tailwind.config.ts: Configuration for Tailwind CSS.
├── tsconfig.json: TypeScript configuration.
├── .idx/dev.nix: Nix configuration for development environment (likely for Google Cloud Shell).
├── .vscode/settings.json: VS Code settings for the project.
└── src
    ├── app: Main application directory in Next.js.
    │   ├── favicon.ico: Favicon for the application.
    │   ├── globals.css: Global CSS styles.
    │   ├── layout.tsx: Root layout component for the application.
    │   └── page.tsx: Main page component (likely the dashboard).
    ├── components: Reusable UI components.
    │   ├── AIAssistantSidebar.tsx: Sidebar component for the AI assistant.
    │   ├── EmployeeDashboard.tsx: Component for displaying employee information.
    │   ├── Header.tsx: Header component for the application.
    │   ├── MainContent.tsx: Main content area of the application.
    │   └── ui:  shadcn/ui components.
    │       ├── accordion.tsx: Accordion component.
    │       └── sidebar.tsx: Sidebar component.
    │   ├── AIAssistant: Components related to the AI assistant.
    │   │   └── AIAssistant.tsx: Main AI assistant component.
    │   └── AppSidebar: Application sidebar components.
    │       └── AppSidebar.tsx: Main application sidebar.
    ├── contexts: React contexts for state management.
    │   ├── ActivityContext.tsx: Context for managing activity data.
    │   ├── EmployeeContext.tsx: Context for managing employee data.
    │   ├── TaskContext.tsx: Context for managing task data.
    │   └── UIContext.tsx: Context for managing UI-related state.
    ├── data: Data files (likely mock or static data).
    │   ├── activityData.ts: Data for activities.
    │   ├── currentTasks.ts: Data for current tasks.
    │   ├── employeeInfo.ts: Data for employee information.
    │   ├── equipmentData.ts: Data for equipment resources.
    │   ├── notificationData.ts: Data for notifications.
    │   ├── performanceData.ts: Data related to performance metrics.
    │   ├── resourceData.ts: General resource data.
    │   ├── scheduleData.ts: Data for schedules.
    │   ├── softwareData.ts: Data for software resources.
    │   ├── taskData.ts: Data for tasks.
    │   ├── taskHistory.ts: Data for task history.
    │   └── taskStats.ts: Data for task statistics.
    │   ├── activities: Data related to activities.
    │   │   ├── activityTypes.ts: Types for activities.
    │   │   ├── incomingActivities.ts: Data for incoming activities.
    │   │   ├── index.ts: Exports for activity data.
    │   │   ├── outgoingActivities.ts: Data for outgoing activities.
    │   │   └── types.ts: Type definitions for activities.
    │   ├── employees: Data related to employees.
    │   │   ├── employeeEducation.ts: Employee education data.
    │   │   ├── employeeExperience.ts: Employee work experience data.
    │   │   ├── employeeSkills.ts: Employee skills data.
    │   │   ├── index.ts: Exports for employee data.
    │   │   └── types.ts: Type definitions for employees.
    │   ├── resources: Data related to resources.
    │   │   ├── equipmentData.ts: Data for equipment resources.
    │   │   ├── index.ts: Exports for resource data.
    │   │   ├── resourceTypes.ts: Types for resources.
    │   │   └── types.ts: Type definitions for resources.
    │   └── tasks: Data related to tasks.
    │       ├── index.ts: Exports for task data.
    │       ├── taskCategories.ts: Task category data.
    │       ├── taskStats.ts: Task statistics data.
    │       ├── tasks.ts: Task data.
    │       └── types.ts: Type definitions for tasks.
    ├── hooks: Custom React hooks.
    │   ├── use-mobile.tsx: Hook for detecting mobile screen size.
    │   └── use-toast.ts: Hook for displaying toast notifications.
    ├── lib: Utility functions.
    │   └── utils.ts: Utility functions.
    ├── services: API interaction services.
    │   ├── activityService.ts: Service for interacting with activity-related APIs.
    │   ├── aiService.ts: Service for interacting with AI-related APIs.
    │   ├── api.ts: Base API configuration.
    │   ├── employeeService.ts: Service for interacting with employee-related APIs.
    │   └── taskService.ts: Service for interacting with task-related APIs.
    └── modules: Feature modules.
        ├── activities: Module for managing activities.
        │   ├── index.ts: Exports for the activities module.
        │   └── components: Components for the activities module.
        │   │   ├── ActivityCard.tsx: Component for displaying an activity.
        │   │   └── ActivityList.tsx: Component for displaying a list of activities.
        │   └── hooks: Hooks for the activities module.
        │       └── useActivities.ts: Hook for fetching and managing activity data.
        ├── ai-assistant: Module for the AI assistant feature.
        │   ├── index.ts: Exports for the AI assistant module.
        │   └── components: Components for the AI assistant module.
        │   │   ├── AIChat.tsx: Component for the AI chat interface.
        │   │   └── AIPrompt.tsx: Component for prompting the AI.
        │   └── hooks: Hooks for the AI assistant module.
        │       └── useAI.ts: Hook for interacting with the AI service.
        ├── employees: Module for managing employees.
        │   ├── index.ts: Exports for the employees module.
        │   └── components: Components for the employees module.
        │   │   ├── EmployeeCard.tsx: Component for displaying an employee.
        │   │   ├── EmployeeInfo.tsx: Component for displaying employee information.
        │   │   ├── EmployeeProfile.tsx: Component for an employee's profile.
        │   │   └── EmployeeProfileContainer.tsx: Container for the employee profile.
        │   └── hooks: Hooks for the employees module.
        │       └── useEmployeeData.ts: Hook for fetching and managing employee data.
        └── tasks: Module for managing tasks.
            ├── index.ts: Exports for the tasks module.
            └── components: Components for the tasks module.
            │   ├── TaskCard.tsx: Component for displaying a task.
            │   ├── TaskList.tsx: Component for displaying a list of tasks.
            │   └── TaskStats.tsx: Component for displaying task statistics.
            └── hooks: Hooks for the tasks module.
                ├── useTaskData.ts: Hook for fetching and managing task data.
                └── useTaskFilters.ts: Hook for managing task filters.

This outline provides a hierarchical view of the project, with descriptions of each file and folder.  It should help in understanding the organization and purpose of different parts of the application.


